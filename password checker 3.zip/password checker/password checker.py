import re

def check_password_strength(password):
    feedback = []

    # Check length
    if len(password) < 8:
        feedback.append("Password is too short (minimum 8 characters).")
    else:
        feedback.append("Good length.")

    # Check uppercase letters
    if re.search(r'[A-Z]', password):
        feedback.append("Contains uppercase letter(s).")
    else:
        feedback.append("Add uppercase letter(s).")

    # Check lowercase letters
    if re.search(r'[a-z]', password):
        feedback.append("Contains lowercase letter(s).")
    else:
        feedback.append("Add lowercase letter(s).")

    # Check digits
    if re.search(r'\d', password):
        feedback.append("Contains digit(s).")
    else:
        feedback.append("Add digit(s).")

    # Check special characters
    if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        feedback.append("Contains special character(s).")
    else:
        feedback.append("Add special character(s).")

    # Assess overall strength
    score = sum([
        len(password) >= 8,
        bool(re.search(r'[A-Z]', password)),
        bool(re.search(r'[a-z]', password)),
        bool(re.search(r'\d', password)),
        bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))
    ])

    if score == 5:
        strength = "Very Strong"
    elif score == 4:
        strength = "Strong"
    elif score == 3:
        strength = "Moderate"
    else:
        strength = "Weak"

    return strength, feedback

if __name__ == "__main__":
    password = input("Enter a password to check: ")
    strength, feedback = check_password_strength(password)

    print(f"\nPassword Strength: {strength}")
    print("Feedback:")
    for f in feedback:
        print(f"- {f}")